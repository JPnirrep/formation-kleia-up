--
-- PostgreSQL database dump
--

\restrict guGLv1WeGNFQKgxdCRMpHcWxST2QQPKtZXjM0aacRsaNPxl1wZ40VcNH2GH3WAG

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.18

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO kleia_user;

--
-- Name: attempts; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.attempts (
    user_id uuid NOT NULL,
    quiz_id uuid NOT NULL,
    score_percent double precision NOT NULL,
    answers json NOT NULL,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp with time zone,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.attempts OWNER TO kleia_user;

--
-- Name: audio_assets; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.audio_assets (
    lesson_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    "order" integer NOT NULL,
    file_url character varying(1024) NOT NULL,
    duration_seconds integer NOT NULL,
    transcript_text text,
    transcript_status character varying(20) NOT NULL,
    language character varying(10) NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audio_assets OWNER TO kleia_user;

--
-- Name: badges; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.badges (
    title character varying(255) NOT NULL,
    description text,
    image_url character varying(1024),
    criteria_type character varying(50) NOT NULL,
    criteria_value character varying(255),
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.badges OWNER TO kleia_user;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.certificates (
    user_id uuid NOT NULL,
    course_id uuid NOT NULL,
    certificate_number character varying(20) NOT NULL,
    issued_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata_json json,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.certificates OWNER TO kleia_user;

--
-- Name: courses; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.courses (
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    short_description character varying(512),
    thumbnail_url character varying(512),
    duration_seconds integer NOT NULL,
    level character varying(20) NOT NULL,
    status character varying(20) NOT NULL,
    category character varying(100),
    is_premium boolean NOT NULL,
    price_ht double precision NOT NULL,
    tva_rate double precision NOT NULL,
    stripe_product_id character varying(255),
    is_linear_progression_enforced boolean NOT NULL,
    created_by uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.courses OWNER TO kleia_user;

--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.enrollments (
    user_id uuid NOT NULL,
    course_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    granted_by uuid,
    granted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp with time zone,
    expires_at timestamp with time zone,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.enrollments OWNER TO kleia_user;

--
-- Name: gamification_points; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.gamification_points (
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_id uuid NOT NULL,
    points integer DEFAULT 0 NOT NULL,
    level character varying(50) DEFAULT 'apprenti'::character varying NOT NULL,
    level_number integer DEFAULT 1 NOT NULL,
    streak_days integer DEFAULT 0 NOT NULL,
    last_activity_date timestamp with time zone,
    total_points_earned integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.gamification_points OWNER TO kleia_user;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.journal_entries (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    lesson_id uuid,
    content text NOT NULL,
    is_shared boolean NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.journal_entries OWNER TO kleia_user;

--
-- Name: lesson_progress; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.lesson_progress (
    user_id uuid NOT NULL,
    lesson_id uuid NOT NULL,
    status character varying(20) NOT NULL,
    completed_at timestamp with time zone,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lesson_progress OWNER TO kleia_user;

--
-- Name: lesson_resources; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.lesson_resources (
    lesson_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    resource_type character varying(50) NOT NULL,
    content text,
    url character varying(1024),
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lesson_resources OWNER TO kleia_user;

--
-- Name: lessons; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.lessons (
    module_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    "order" integer NOT NULL,
    lesson_type character varying(20) NOT NULL,
    duration_seconds integer NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lessons OWNER TO kleia_user;

--
-- Name: modules; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.modules (
    course_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    "order" integer NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.modules OWNER TO kleia_user;

--
-- Name: questions; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.questions (
    quiz_id uuid NOT NULL,
    text text NOT NULL,
    "order" integer NOT NULL,
    question_type character varying(20) NOT NULL,
    options json NOT NULL,
    explanation text,
    points integer NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.questions OWNER TO kleia_user;

--
-- Name: quizzes; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.quizzes (
    lesson_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    passing_score_percent integer NOT NULL,
    max_attempts integer,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.quizzes OWNER TO kleia_user;

--
-- Name: resource_assets; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.resource_assets (
    lesson_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    "order" integer NOT NULL,
    file_url character varying(1024) NOT NULL,
    resource_type character varying(20) NOT NULL,
    file_size_bytes integer,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.resource_assets OWNER TO kleia_user;

--
-- Name: user_badges; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.user_badges (
    user_id uuid NOT NULL,
    badge_id uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_badges OWNER TO kleia_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.users (
    email character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    avatar_url character varying(512),
    role character varying(20) NOT NULL,
    auth_provider character varying(20) NOT NULL,
    auth_sub character varying(255),
    password_hash character varying(255),
    is_active boolean NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.users OWNER TO kleia_user;

--
-- Name: video_assets; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.video_assets (
    lesson_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    "order" integer NOT NULL,
    source_storage_key character varying(512),
    playback_manifest_url character varying(512),
    thumbnail_url character varying(512),
    duration_seconds integer NOT NULL,
    status character varying(20) NOT NULL,
    language character varying(10) NOT NULL,
    visibility character varying(20) NOT NULL,
    completion_threshold_percent integer NOT NULL,
    created_by uuid NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.video_assets OWNER TO kleia_user;

--
-- Name: video_events; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.video_events (
    user_id uuid NOT NULL,
    video_asset_id uuid NOT NULL,
    session_id character varying(255) NOT NULL,
    event_type character varying(30) NOT NULL,
    position_seconds double precision NOT NULL,
    payload_json json,
    occurred_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.video_events OWNER TO kleia_user;

--
-- Name: video_progress; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.video_progress (
    user_id uuid NOT NULL,
    video_asset_id uuid NOT NULL,
    last_position_seconds double precision NOT NULL,
    max_position_seconds double precision NOT NULL,
    percent_watched double precision NOT NULL,
    completed boolean NOT NULL,
    completed_at timestamp with time zone,
    last_played_at timestamp with time zone,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.video_progress OWNER TO kleia_user;

--
-- Name: video_tracks; Type: TABLE; Schema: public; Owner: kleia_user
--

CREATE TABLE public.video_tracks (
    video_asset_id uuid NOT NULL,
    kind character varying(20) NOT NULL,
    language character varying(10) NOT NULL,
    label character varying(255) NOT NULL,
    file_url character varying(512) NOT NULL,
    is_default boolean NOT NULL,
    status character varying(20) NOT NULL,
    id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.video_tracks OWNER TO kleia_user;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.alembic_version (version_num) FROM stdin;
499779af7e6b
\.


--
-- Data for Name: attempts; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.attempts (user_id, quiz_id, score_percent, answers, started_at, completed_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audio_assets; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.audio_assets (lesson_id, title, description, "order", file_url, duration_seconds, transcript_text, transcript_status, language, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: badges; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.badges (title, description, image_url, criteria_type, criteria_value, id, created_at, updated_at) FROM stdin;
Premier Pas	Félicitations pour avoir terminé votre première leçon !	\N	first_lesson	\N	a374a0d9-b905-48d7-bd5f-51acd8c0f562	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
Expert Quiz	Vous avez obtenu un score parfait de 100% à un quiz !	\N	perfect_quiz	\N	b1721100-4b9d-4a8b-95f4-e17cdad071fb	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
Diplômé d'Agora	Vous avez terminé l'intégralité d'un parcours de formation.	\N	course_completion	\N	2cbc500c-07ba-4411-b350-aed8c290371f	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.certificates (user_id, course_id, certificate_number, issued_at, metadata_json, id, created_at, updated_at) FROM stdin;
7c8c5c68-d9b6-455b-a276-b783c0cab2d3	dab9ed7f-5aff-444b-aa52-c09e5b3ca77d	KLEIA-2025-0047	2026-06-01 07:49:32.470682+00	{"seed": true}	c5ecfe98-f8d5-44de-bd15-16a7bd48efa1	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.courses (title, slug, description, short_description, thumbnail_url, duration_seconds, level, status, category, is_premium, price_ht, tva_rate, stripe_product_id, is_linear_progression_enforced, created_by, id, created_at, updated_at) FROM stdin;
L'Architecture du Message	architecture-message	Apprenez à structurer vos messages pour captiver votre audience. Ce cours vous guide pas à pas dans la construction d'une communication claire, impactante et mémorable.	Structurez vos messages pour captiver votre audience.	\N	5400	débutant	published	communication	f	0	20	\N	t	7c8c5c68-d9b6-455b-a276-b783c0cab2d3	dab9ed7f-5aff-444b-aa52-c09e5b3ca77d	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
L'Incarnation & Le Jour J	incarnation-jour-j	Préparez-vous mentalement et physiquement à monter sur scène. De la gestion du trac à la présence scénique, ce cours vous prépare à briller le jour J.	Préparez-vous à briller sur scène.	\N	7200	intermédiaire	published	prise de parole	f	0	20	\N	t	7c8c5c68-d9b6-455b-a276-b783c0cab2d3	80707e5f-63c3-467c-bdc4-d1cfe03f19e6	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
Le Mindset du Speaker	mindset-speaker	Développez la mentalité d'un speaker d'exception. Confiance en soi, résilience et quête d'excellence sont au programme de ce cours avancé.	Développez la mentalité d'un speaker d'exception.	\N	8400	avancé	published	développement personnel	f	0	20	\N	t	7c8c5c68-d9b6-455b-a276-b783c0cab2d3	48aae487-5c15-4247-a60e-eb06ff5d5fba	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
Déployer son Leadership	deployer-leadership	Développez un leadership authentique qui inspire et mobilise. De la définition de votre style à la mise en action, ce cours vous accompagne dans votre transformation de leader.	Développez un leadership authentique et inspirant.	\N	9600	avancé	published	leadership	f	0	20	\N	t	7c8c5c68-d9b6-455b-a276-b783c0cab2d3	9e940f1b-e901-4ef7-a739-af8d3aa3b52c	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
\.


--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.enrollments (user_id, course_id, status, granted_by, granted_at, completed_at, expires_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gamification_points; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.gamification_points (id, created_at, updated_at, user_id, points, level, level_number, streak_days, last_activity_date, total_points_earned) FROM stdin;
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.journal_entries (id, user_id, lesson_id, content, is_shared, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lesson_progress; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.lesson_progress (user_id, lesson_id, status, completed_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lesson_resources; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.lesson_resources (lesson_id, title, resource_type, content, url, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: lessons; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.lessons (module_id, title, description, "order", lesson_type, duration_seconds, id, created_at, updated_at) FROM stdin;
fb2ca94c-35ea-41b6-b545-050e5524d863	Introduction à l'architecture du message	Découvrez pourquoi la structure est la clé d'un message réussi.	1	video	480	48a9b123-b8e4-4d6e-b350-fcfff9762b08	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
fb2ca94c-35ea-41b6-b545-050e5524d863	Les piliers d'un message percutant	Identifiez les trois piliers fondamentaux de tout message impactant.	2	video	600	3dc2c893-1e97-44f4-ae28-68083b840148	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
fb2ca94c-35ea-41b6-b545-050e5524d863	Structurer son discours	Apprenez les différentes structures narratives et quand les utiliser.	3	video	720	8003131e-2196-4bf6-8597-bd7bff37bf69	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
4a1b6196-f869-41c0-8814-99d66bbb3ae9	Simplifier sans perdre le fond	Transformez des idées complexes en messages accessibles.	1	video	540	69ca43e2-f2c5-449b-aaf8-2151e2c19623	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
4a1b6196-f869-41c0-8814-99d66bbb3ae9	Le pouvoir des exemples concrets	Utilisez des exemples pour ancrer votre message dans le réel.	2	video	480	9fc9d700-a91b-4b29-bf01-f6e129887635	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
4a1b6196-f869-41c0-8814-99d66bbb3ae9	Éviter les pièges de la communication	Les erreurs courantes qui nuisent à la clarté de votre message.	3	video	600	f13f4b30-89b6-454c-9ed7-9c53ca2b5b97	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
c96a0be8-6502-4446-9099-5b79138008d8	Connecter avec son audience	Établissez une connexion authentique dès les premières secondes.	1	video	660	c565f060-95d2-41f0-a550-ba12a1d775fa	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
c96a0be8-6502-4446-9099-5b79138008d8	Le storytelling comme outil	Maîtrisez l'art du récit pour rendre votre message inoubliable.	2	video	720	49af5891-dc27-4e51-81b7-3e4b39d6cba2	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
c96a0be8-6502-4446-9099-5b79138008d8	Créer une expérience mémorable	Concevez des moments forts qui resteront gravés dans les mémoires.	3	video	600	f88b8972-c371-42db-9836-b05a43af7092	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
b914c591-6ffa-44ad-8f5d-162bd94b2db4	Visualiser le succès	Utilisez la visualisation pour programmer votre réussite.	1	video	480	163b1bbc-a858-44ec-bb0d-8f5b122ae546	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
b914c591-6ffa-44ad-8f5d-162bd94b2db4	Gérer le trac	Transformez votre stress en énergie positive.	2	video	600	232d05cc-1024-44b4-94f1-e9a43eb3e4ea	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
b914c591-6ffa-44ad-8f5d-162bd94b2db4	Techniques de respiration	Maîtrisez votre souffle pour maîtriser votre voix et votre esprit.	3	video	420	655b92fb-4216-47e4-9885-387336e85fb5	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
b914c591-6ffa-44ad-8f5d-162bd94b2db4	Ancrage et présence	Ancrez-vous dans l'instant présent pour être pleinement disponible.	4	video	540	bc1cff8b-59b1-4bc5-8909-69b5889a69b7	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
993a26be-d8ea-4b30-889a-b90dc0ff43cb	Occuper l'espace	Apprenez à utiliser l'espace scénique à votre avantage.	1	video	600	89b1c0ba-143e-4bf0-b235-2921e41d1706	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
993a26be-d8ea-4b30-889a-b90dc0ff43cb	La gestuelle qui parle	Utilisez vos mains, votre posture et vos déplacements pour renforcer votre message.	2	video	540	fed3cd1d-44a3-4a01-b6c1-391802a1fc55	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
993a26be-d8ea-4b30-889a-b90dc0ff43cb	Le regard et la connexion	Établissez un contact visuel puissant avec chaque personne dans la salle.	3	video	480	fe2d6cb4-d1e4-4f53-9298-c6e3dfd08fe3	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
c672ecbb-6348-4805-a441-11eb86a5b44c	Rebondir sur l'imprévu	Faites des imprévus vos meilleurs alliés.	1	video	540	1e61b576-6793-4f4c-9ab9-6017b728df64	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
c672ecbb-6348-4805-a441-11eb86a5b44c	Gérer les questions difficiles	Répondez avec aisance aux questions les plus déstabilisantes.	2	video	600	47d9d3f3-58d4-4851-afcf-f8e75a79e30a	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
c672ecbb-6348-4805-a441-11eb86a5b44c	L'humour en situation	Utilisez l'humour à bon escient pour détendre l'atmosphère.	3	video	480	d8320123-b355-4495-9ace-db08e82af78b	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
f50d7eb6-0cbf-4c24-96ac-80e7cd00fc5e	Construire sa légitimité	Reconnaissez et affirmez votre légitimité à prendre la parole.	1	video	540	5423fcbe-0349-4744-b253-e9af46bec452	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
f50d7eb6-0cbf-4c24-96ac-80e7cd00fc5e	Dépasser le syndrome de l'imposteur	Identifiez et surmontez les pensées qui vous limitent.	2	video	600	f1cb5d96-52dc-4fd3-abe2-247f081e1ac5	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
f50d7eb6-0cbf-4c24-96ac-80e7cd00fc5e	L'auto-persuasion positive	Utilisez le dialogue intérieur pour renforcer votre confiance.	3	video	480	0323fc91-b29a-4de5-8314-ad0f6a3e988a	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
f50d7eb6-0cbf-4c24-96ac-80e7cd00fc5e	La routine du speaker	Mettez en place des rituels qui vous préparent au succès.	4	video	420	b10284ad-3d48-4bcd-847b-77d89efebde0	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
c79faabd-d41d-4b75-ad33-0373a8798d74	Transformer les échecs en force	Faites de chaque échec un tremplin vers la réussite.	1	video	540	2b813849-c0d8-4982-bd16-6d295d122db6	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
c79faabd-d41d-4b75-ad33-0373a8798d74	L'adaptabilité en toutes circonstances	Restez agile face aux changements et aux imprévus.	2	video	600	f9ea4148-d3a6-4170-ad3a-ff62e04bd7d2	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
c79faabd-d41d-4b75-ad33-0373a8798d74	Cultiver un mindset de croissance	Adoptez une mentalité d'apprentissage continu.	3	video	480	516ee9da-f0c5-43a0-b898-28120f0956d0	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
546efffe-7da8-4b35-a2e8-290e9b1a570a	La pratique délibérée	Structurez votre entraînement pour des progrès rapides et durables.	1	video	600	9770728b-0f94-4b2b-8ca3-f8a5d5652e9a	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
546efffe-7da8-4b35-a2e8-290e9b1a570a	Le feedback comme carburant	Accueillez et utilisez le feedback pour vous améliorer.	2	video	480	71452c38-e381-417b-ad51-7a00d91e915b	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
546efffe-7da8-4b35-a2e8-290e9b1a570a	L'évolution du speaker	Tracez votre chemin d'évolution sur le long terme.	3	video	540	ab94bf94-f231-4862-9b89-0214008d52bb	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
546efffe-7da8-4b35-a2e8-290e9b1a570a	Transmettre aux autres	Devenez mentor et partagez votre expérience avec la prochaine génération.	4	video	600	c7de2406-b502-4e75-8307-4da4b063c0a9	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
59ce5bbe-210b-4639-8b0f-df036377d0bf	Définir son style de leadership	Identifiez le style de leadership qui vous correspond authentiquement.	1	video	600	d6c92b11-8ce9-4d39-96a1-1e5ce140cf27	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
59ce5bbe-210b-4639-8b0f-df036377d0bf	Leadership et authenticité	Osez être vous-même pour inspirer durablement.	2	video	540	df375843-a762-433e-970f-f79149ea0f35	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
59ce5bbe-210b-4639-8b0f-df036377d0bf	Inspirer par l'exemple	Montrez la voie par vos actions, pas seulement par vos paroles.	3	video	480	9d223117-babf-4d3b-a76f-1a7d78d07d7e	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
660f4658-b2e2-4fa5-b5b0-890af34c5e77	Parler avec autorité et bienveillance	Trouvez l'équilibre entre fermeté et empathie.	1	video	540	97cf564b-0f4e-4dd4-8194-b2ce4de65b17	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
660f4658-b2e2-4fa5-b5b0-890af34c5e77	Les réunions qui comptent	Animez des réunions efficaces qui génèrent de l'engagement.	2	video	600	dd02d4ec-3a93-4a09-980f-081471f58e51	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
660f4658-b2e2-4fa5-b5b0-890af34c5e77	La communication non-verbale du leader	Votre corps parle plus fort que vos mots — apprenez à le contrôler.	3	video	480	7f3ff55d-05ee-49e0-b01b-b73bde92e58a	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
660f4658-b2e2-4fa5-b5b0-890af34c5e77	Donner du feedback puissant	Formulez des feedbacks qui font grandir sans blesser.	4	video	540	8c2077ae-5122-44ed-a2c0-c7aab86c5f01	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
96d4c26a-b954-4606-8c38-069455ebce82	Créer une vision partagée	Articulez une vision qui donne envie de s'engager.	1	video	600	c7201c8c-4bc6-412d-9ee0-709442c40251	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
96d4c26a-b954-4606-8c38-069455ebce82	Favoriser l'engagement	Les leviers pour susciter et maintenir l'engagement de votre équipe.	2	video	540	8b4999f0-9245-4365-8329-da854e45d4de	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
96d4c26a-b954-4606-8c38-069455ebce82	Gérer les conflits	Transformez les tensions en opportunités de croissance.	3	video	600	a31b7c41-7e34-4832-b276-44384696b55e	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
4fa6e92f-a9d0-4bd9-8031-9fa36751dd5f	Plan d'action sur 90 jours	Structurez vos 90 premiers jours en tant que leader.	1	video	480	66b8fb07-4431-406f-af2e-e59d731dbf2e	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
4fa6e92f-a9d0-4bd9-8031-9fa36751dd5f	Mesurer son impact	Définissez des indicateurs pour mesurer l'impact de votre leadership.	2	video	420	b6330ba5-e257-4dac-94a4-476a02d83a03	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
4fa6e92f-a9d0-4bd9-8031-9fa36751dd5f	Le leadership en mouvement	Incarnez votre leadership chaque jour, dans chaque interaction.	3	video	540	b2084ed4-e4da-4dec-980b-5e72367def7e	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
\.


--
-- Data for Name: modules; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.modules (course_id, title, description, "order", id, created_at, updated_at) FROM stdin;
dab9ed7f-5aff-444b-aa52-c09e5b3ca77d	Les Fondamentaux de la Communication	Les bases essentielles pour construire un message solide.	1	fb2ca94c-35ea-41b6-b545-050e5524d863	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
dab9ed7f-5aff-444b-aa52-c09e5b3ca77d	La Clarté du Message	Rendez votre message limpide pour tout type d'audience.	2	4a1b6196-f869-41c0-8814-99d66bbb3ae9	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
dab9ed7f-5aff-444b-aa52-c09e5b3ca77d	L'Impact Émotionnel	Donnez une dimension émotionnelle à votre message pour marquer les esprits.	3	c96a0be8-6502-4446-9099-5b79138008d8	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
80707e5f-63c3-467c-bdc4-d1cfe03f19e6	Préparation Mentale	Les techniques mentales pour aborder sereinement votre intervention.	1	b914c591-6ffa-44ad-8f5d-162bd94b2db4	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
80707e5f-63c3-467c-bdc4-d1cfe03f19e6	La Présence Scénique	Occupez l'espace et captez l'attention par votre présence.	2	993a26be-d8ea-4b30-889a-b90dc0ff43cb	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
80707e5f-63c3-467c-bdc4-d1cfe03f19e6	L'Art de l'Improvisation	Sachez rebondir et vous adapter en temps réel.	3	c672ecbb-6348-4805-a441-11eb86a5b44c	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
48aae487-5c15-4247-a60e-eb06ff5d5fba	La Confiance en Soi	Construisez une confiance inébranlable en vos capacités.	1	f50d7eb6-0cbf-4c24-96ac-80e7cd00fc5e	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
48aae487-5c15-4247-a60e-eb06ff5d5fba	La Résilience	Rebondissez après chaque expérience, bonne ou mauvaise.	2	c79faabd-d41d-4b75-ad33-0373a8798d74	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
48aae487-5c15-4247-a60e-eb06ff5d5fba	L'Excellence Continue	Ne cessez jamais de progresser et d'élever votre niveau.	3	546efffe-7da8-4b35-a2e8-290e9b1a570a	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
9e940f1b-e901-4ef7-a739-af8d3aa3b52c	Les Fondations du Leadership	Construisez les bases solides de votre leadership.	1	59ce5bbe-210b-4639-8b0f-df036377d0bf	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
9e940f1b-e901-4ef7-a739-af8d3aa3b52c	La Communication du Leader	Maîtrisez l'art de la communication inspirante.	2	660f4658-b2e2-4fa5-b5b0-890af34c5e77	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
9e940f1b-e901-4ef7-a739-af8d3aa3b52c	Mobiliser et Fédérer	Créez une dynamique collective autour de votre vision.	3	96d4c26a-b954-4606-8c38-069455ebce82	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
9e940f1b-e901-4ef7-a739-af8d3aa3b52c	Passer à l'Action	Mettez en œuvre votre leadership au quotidien.	4	4fa6e92f-a9d0-4bd9-8031-9fa36751dd5f	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.questions (quiz_id, text, "order", question_type, options, explanation, points, id, created_at, updated_at) FROM stdin;
329d7520-11db-433b-8a85-3586391c7de4	Quel est l'élément le plus important dans un message ?	1	mcq	[{"label": "La structure", "value": "structure", "is_correct": true}, {"label": "La longueur", "value": "length", "is_correct": false}, {"label": "Le vocabulaire", "value": "vocab", "is_correct": false}, {"label": "Le support", "value": "medium", "is_correct": false}]	La structure est fondamentale car elle donne du sens et guide l'audience à travers votre message.	2	4721c58f-db3a-486d-a7ed-bd64c81d1ffb	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
329d7520-11db-433b-8a85-3586391c7de4	Combien de piliers fondamentaux composent un message percutant ?	2	mcq	[{"label": "2", "value": "2", "is_correct": false}, {"label": "3", "value": "3", "is_correct": true}, {"label": "4", "value": "4", "is_correct": false}, {"label": "5", "value": "5", "is_correct": false}]	Trois piliers : la clarté, l'impact émotionnel et la mémorabilité.	2	be4b12da-bfa5-4fe1-aa10-f38203a74c02	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
329d7520-11db-433b-8a85-3586391c7de4	Quelle structure narrative est recommandée pour un discours inspirant ?	3	mcq	[{"label": "Chronologique", "value": "chrono", "is_correct": false}, {"label": "Probl\\u00e8me-Solution", "value": "problem", "is_correct": false}, {"label": "Le voyage du h\\u00e9ros", "value": "hero", "is_correct": true}, {"label": "Cause \\u00e0 effet", "value": "causal", "is_correct": false}]	La structure du voyage du héros est particulièrement puissante pour les discours inspirants car elle crée une résonance émotionnelle.	3	4fccfef3-dbee-4414-84c4-d3ffb4e2b82c	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
\.


--
-- Data for Name: quizzes; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.quizzes (lesson_id, title, passing_score_percent, max_attempts, id, created_at, updated_at) FROM stdin;
48a9b123-b8e4-4d6e-b350-fcfff9762b08	Quiz : Introduction à l'architecture du message	70	3	329d7520-11db-433b-8a85-3586391c7de4	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
\.


--
-- Data for Name: resource_assets; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.resource_assets (lesson_id, title, description, "order", file_url, resource_type, file_size_bytes, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_badges; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.user_badges (user_id, badge_id, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.users (email, display_name, avatar_url, role, auth_provider, auth_sub, password_hash, is_active, id, created_at, updated_at) FROM stdin;
clara.f@example.com	Clara Fontaine	\N	learner	email	\N	$2b$12$8kGYZTv.FfMZe5BjhNFBPuSeGa2Ny2ppRdnGg8jh1n8nCjeuYwkum	t	7f6b5c45-57bb-4e75-8f7e-cc0f2701a38a	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
sandrina@kleia-up.com	Sandrina Perrin	\N	admin	email	\N	$2b$12$WiFqSYjuCQ9IRcSL6bHYYuOLstNniNFgU3Zr58cVk97FU73/eS8yO	t	7c8c5c68-d9b6-455b-a276-b783c0cab2d3	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
admin@kleia-up.com	Admin	\N	admin	email	\N	$2b$12$A7D33Zw0XPlLc/I0vEIaPuVlJJeAJwV9uJOLnqcjIfLca.Sz7Fm32	t	4b3dc3c9-2e3c-4827-99db-54dc429b501e	2026-06-01 07:49:32.470682+00	2026-06-01 07:49:32.470682+00
\.


--
-- Data for Name: video_assets; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.video_assets (lesson_id, title, description, "order", source_storage_key, playback_manifest_url, thumbnail_url, duration_seconds, status, language, visibility, completion_threshold_percent, created_by, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: video_events; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.video_events (user_id, video_asset_id, session_id, event_type, position_seconds, payload_json, occurred_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: video_progress; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.video_progress (user_id, video_asset_id, last_position_seconds, max_position_seconds, percent_watched, completed, completed_at, last_played_at, id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: video_tracks; Type: TABLE DATA; Schema: public; Owner: kleia_user
--

COPY public.video_tracks (video_asset_id, kind, language, label, file_url, is_default, status, id, created_at, updated_at) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: attempts attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.attempts
    ADD CONSTRAINT attempts_pkey PRIMARY KEY (id);


--
-- Name: audio_assets audio_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.audio_assets
    ADD CONSTRAINT audio_assets_pkey PRIMARY KEY (id);


--
-- Name: badges badges_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_pkey PRIMARY KEY (id);


--
-- Name: badges badges_title_key; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_title_key UNIQUE (title);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: gamification_points gamification_points_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.gamification_points
    ADD CONSTRAINT gamification_points_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: lesson_progress lesson_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_pkey PRIMARY KEY (id);


--
-- Name: lesson_resources lesson_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.lesson_resources
    ADD CONSTRAINT lesson_resources_pkey PRIMARY KEY (id);


--
-- Name: lessons lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_pkey PRIMARY KEY (id);


--
-- Name: modules modules_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_pkey PRIMARY KEY (id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: quizzes quizzes_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_pkey PRIMARY KEY (id);


--
-- Name: resource_assets resource_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.resource_assets
    ADD CONSTRAINT resource_assets_pkey PRIMARY KEY (id);


--
-- Name: enrollments uq_enrollment_user_course; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT uq_enrollment_user_course UNIQUE (user_id, course_id);


--
-- Name: lessons uq_lesson_module_order; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT uq_lesson_module_order UNIQUE (module_id, "order");


--
-- Name: lesson_progress uq_lesson_progress_user_lesson; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT uq_lesson_progress_user_lesson UNIQUE (user_id, lesson_id);


--
-- Name: modules uq_module_course_order; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT uq_module_course_order UNIQUE (course_id, "order");


--
-- Name: user_badges uq_user_badge; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT uq_user_badge UNIQUE (user_id, badge_id);


--
-- Name: video_progress uq_video_progress_user_asset; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_progress
    ADD CONSTRAINT uq_video_progress_user_asset UNIQUE (user_id, video_asset_id);


--
-- Name: user_badges user_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_pkey PRIMARY KEY (id);


--
-- Name: users users_auth_sub_key; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_auth_sub_key UNIQUE (auth_sub);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: video_assets video_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_assets
    ADD CONSTRAINT video_assets_pkey PRIMARY KEY (id);


--
-- Name: video_events video_events_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_events
    ADD CONSTRAINT video_events_pkey PRIMARY KEY (id);


--
-- Name: video_progress video_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_progress
    ADD CONSTRAINT video_progress_pkey PRIMARY KEY (id);


--
-- Name: video_tracks video_tracks_pkey; Type: CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_tracks
    ADD CONSTRAINT video_tracks_pkey PRIMARY KEY (id);


--
-- Name: ix_attempts_quiz_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_attempts_quiz_id ON public.attempts USING btree (quiz_id);


--
-- Name: ix_attempts_user_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_attempts_user_id ON public.attempts USING btree (user_id);


--
-- Name: ix_audio_assets_lesson_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_audio_assets_lesson_id ON public.audio_assets USING btree (lesson_id);


--
-- Name: ix_certificates_certificate_number; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE UNIQUE INDEX ix_certificates_certificate_number ON public.certificates USING btree (certificate_number);


--
-- Name: ix_certificates_course_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_certificates_course_id ON public.certificates USING btree (course_id);


--
-- Name: ix_certificates_user_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_certificates_user_id ON public.certificates USING btree (user_id);


--
-- Name: ix_courses_created_by; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_courses_created_by ON public.courses USING btree (created_by);


--
-- Name: ix_courses_slug; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE UNIQUE INDEX ix_courses_slug ON public.courses USING btree (slug);


--
-- Name: ix_enrollments_course_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_enrollments_course_id ON public.enrollments USING btree (course_id);


--
-- Name: ix_enrollments_user_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_enrollments_user_id ON public.enrollments USING btree (user_id);


--
-- Name: ix_gamification_points_user_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE UNIQUE INDEX ix_gamification_points_user_id ON public.gamification_points USING btree (user_id);


--
-- Name: ix_journal_entries_lesson_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_journal_entries_lesson_id ON public.journal_entries USING btree (lesson_id);


--
-- Name: ix_journal_entries_user_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_journal_entries_user_id ON public.journal_entries USING btree (user_id);


--
-- Name: ix_lesson_progress_lesson_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_lesson_progress_lesson_id ON public.lesson_progress USING btree (lesson_id);


--
-- Name: ix_lesson_progress_user_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_lesson_progress_user_id ON public.lesson_progress USING btree (user_id);


--
-- Name: ix_lesson_resources_lesson_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_lesson_resources_lesson_id ON public.lesson_resources USING btree (lesson_id);


--
-- Name: ix_lessons_module_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_lessons_module_id ON public.lessons USING btree (module_id);


--
-- Name: ix_modules_course_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_modules_course_id ON public.modules USING btree (course_id);


--
-- Name: ix_questions_quiz_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_questions_quiz_id ON public.questions USING btree (quiz_id);


--
-- Name: ix_quizzes_lesson_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_quizzes_lesson_id ON public.quizzes USING btree (lesson_id);


--
-- Name: ix_resource_assets_lesson_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_resource_assets_lesson_id ON public.resource_assets USING btree (lesson_id);


--
-- Name: ix_user_badges_badge_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_user_badges_badge_id ON public.user_badges USING btree (badge_id);


--
-- Name: ix_user_badges_user_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_user_badges_user_id ON public.user_badges USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_video_assets_created_by; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_video_assets_created_by ON public.video_assets USING btree (created_by);


--
-- Name: ix_video_assets_lesson_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_video_assets_lesson_id ON public.video_assets USING btree (lesson_id);


--
-- Name: ix_video_events_session_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_video_events_session_id ON public.video_events USING btree (session_id);


--
-- Name: ix_video_events_user_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_video_events_user_id ON public.video_events USING btree (user_id);


--
-- Name: ix_video_events_video_asset_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_video_events_video_asset_id ON public.video_events USING btree (video_asset_id);


--
-- Name: ix_video_progress_user_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_video_progress_user_id ON public.video_progress USING btree (user_id);


--
-- Name: ix_video_progress_video_asset_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_video_progress_video_asset_id ON public.video_progress USING btree (video_asset_id);


--
-- Name: ix_video_tracks_video_asset_id; Type: INDEX; Schema: public; Owner: kleia_user
--

CREATE INDEX ix_video_tracks_video_asset_id ON public.video_tracks USING btree (video_asset_id);


--
-- Name: attempts attempts_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.attempts
    ADD CONSTRAINT attempts_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quizzes(id);


--
-- Name: attempts attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.attempts
    ADD CONSTRAINT attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: audio_assets audio_assets_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.audio_assets
    ADD CONSTRAINT audio_assets_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: certificates certificates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: courses courses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: enrollments enrollments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: enrollments enrollments_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- Name: enrollments enrollments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: gamification_points gamification_points_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.gamification_points
    ADD CONSTRAINT gamification_points_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: journal_entries journal_entries_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id) ON DELETE SET NULL;


--
-- Name: journal_entries journal_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lesson_progress lesson_progress_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id);


--
-- Name: lesson_progress lesson_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: lesson_resources lesson_resources_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.lesson_resources
    ADD CONSTRAINT lesson_resources_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id) ON DELETE CASCADE;


--
-- Name: lessons lessons_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.modules(id);


--
-- Name: modules modules_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.modules
    ADD CONSTRAINT modules_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id);


--
-- Name: questions questions_quiz_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_quiz_id_fkey FOREIGN KEY (quiz_id) REFERENCES public.quizzes(id);


--
-- Name: quizzes quizzes_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.quizzes
    ADD CONSTRAINT quizzes_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id);


--
-- Name: resource_assets resource_assets_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.resource_assets
    ADD CONSTRAINT resource_assets_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id) ON DELETE CASCADE;


--
-- Name: user_badges user_badges_badge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_badge_id_fkey FOREIGN KEY (badge_id) REFERENCES public.badges(id) ON DELETE CASCADE;


--
-- Name: user_badges user_badges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: video_assets video_assets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_assets
    ADD CONSTRAINT video_assets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: video_assets video_assets_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_assets
    ADD CONSTRAINT video_assets_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lessons(id);


--
-- Name: video_events video_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_events
    ADD CONSTRAINT video_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: video_events video_events_video_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_events
    ADD CONSTRAINT video_events_video_asset_id_fkey FOREIGN KEY (video_asset_id) REFERENCES public.video_assets(id);


--
-- Name: video_progress video_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_progress
    ADD CONSTRAINT video_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: video_progress video_progress_video_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_progress
    ADD CONSTRAINT video_progress_video_asset_id_fkey FOREIGN KEY (video_asset_id) REFERENCES public.video_assets(id);


--
-- Name: video_tracks video_tracks_video_asset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kleia_user
--

ALTER TABLE ONLY public.video_tracks
    ADD CONSTRAINT video_tracks_video_asset_id_fkey FOREIGN KEY (video_asset_id) REFERENCES public.video_assets(id);


--
-- PostgreSQL database dump complete
--

\unrestrict guGLv1WeGNFQKgxdCRMpHcWxST2QQPKtZXjM0aacRsaNPxl1wZ40VcNH2GH3WAG

